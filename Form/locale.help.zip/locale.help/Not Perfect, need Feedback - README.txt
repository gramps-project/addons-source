1. Directory structure, new subdir (not using existing locale) one

2. _LOG.debug('[DEBUG] locale.getlocale() : %s' % str(locale.getlocale()))
        --> [DEBUG] locale.getlocale() : ('English_United Kingdom', '1252')

3. Why "English_United Kingdom" and not "en_gb" or similar

4. How to tell if generically "english" or "indian" etc.